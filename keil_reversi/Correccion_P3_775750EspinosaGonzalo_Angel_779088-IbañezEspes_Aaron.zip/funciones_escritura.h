void escritura_comenzar(const char buff[]);
void escritura_continuar(void);
