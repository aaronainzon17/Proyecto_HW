#include <LPC210X.H>
#include <inttypes.h>
enum {inicio,esperando_fin};
void gestor_UART(uint32_t entrada);
