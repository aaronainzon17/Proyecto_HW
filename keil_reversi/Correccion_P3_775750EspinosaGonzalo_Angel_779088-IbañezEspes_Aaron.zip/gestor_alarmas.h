#include "eventos.h"
void iniciar_alarmas(void);
void gestor_alarmas_control_cola(struct EventInfo nueva_alarma);
void gestor_alarmas_control_alarma(void);
void introducir_alarma_power(void);
void introducir_alarma_viualizacion(void);
void gestor_alarma_visualizacion_1s(void);
void introducir_alarma_iddle(void);
void apagar_alarma_iddle(void);
void introducir_alarma_aceptar(void);
void quitar_alarma_aceptar(void);
void introducir_alarma_parpadeo_aceptar(void);
void quitar_alarma_parpadeo_aceptar(void);
