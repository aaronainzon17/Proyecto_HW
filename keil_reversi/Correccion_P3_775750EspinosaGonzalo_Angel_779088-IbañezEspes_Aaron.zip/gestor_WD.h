#include <inttypes.h>
void WT_init(int sec);
void feed_watchdog (void);
