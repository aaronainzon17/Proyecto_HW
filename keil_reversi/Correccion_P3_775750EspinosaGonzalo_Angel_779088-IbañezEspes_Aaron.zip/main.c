#include <LPC210x.H>                       /* LPC210x definitions */
#include "planificador.h"

// MAIN 
int main (void) {
	//Llama al planificador
	planificador();
}
