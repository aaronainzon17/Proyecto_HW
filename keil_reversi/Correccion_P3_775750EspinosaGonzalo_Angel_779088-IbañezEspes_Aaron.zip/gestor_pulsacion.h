#include <stdint.h>
#include "eventos.h"

enum {
	pulsado,
	no_pulsado
};

void Gestor_Pulsacion_Control(uint32_t Id_Evento);
