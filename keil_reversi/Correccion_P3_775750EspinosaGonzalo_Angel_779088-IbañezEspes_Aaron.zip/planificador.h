void planificador (void);
