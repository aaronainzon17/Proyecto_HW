void init_serial (void);
void sendchar (int ch) ;
int getchar (void);
