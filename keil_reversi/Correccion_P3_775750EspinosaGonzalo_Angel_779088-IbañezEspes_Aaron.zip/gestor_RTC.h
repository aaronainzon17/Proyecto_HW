#include <inttypes.h>
void RTC_init(void);
int RTC_leer_minutos(void);
int RTC_leer_segundos(void);
