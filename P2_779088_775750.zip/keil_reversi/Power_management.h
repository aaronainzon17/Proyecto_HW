void PM_power_down (void); 
void PM_idle (void);
