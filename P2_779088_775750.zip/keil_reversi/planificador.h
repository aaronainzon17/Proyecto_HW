void Planificador_Control(void);
