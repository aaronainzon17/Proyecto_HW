void gestor_IO_init(void);
