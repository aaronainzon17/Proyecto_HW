void eint0_init (void);
unsigned int eint1_read_count(void);
unsigned int eint2_read_count(void);
void eint1_clear_nueva_pulsacion(void);
void eint2_clear_nueva_pulsacion(void);
unsigned int eint2_read_count(void);
unsigned int eint1_read_nueva_pulsacion(void);
unsigned int eint2_read_nueva_pulsacion(void);
