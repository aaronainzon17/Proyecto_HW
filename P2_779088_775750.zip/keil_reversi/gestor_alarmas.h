#include "eventos.h"
void iniciar_alarmas(void);
void gestor_alarmas_control_cola(struct EventInfo nueva_alarma);
void gestor_alarmas_control_alarma(void);
